import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, tap, catchError, finalize, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { TokenService } from '../services/token.service';
import { ToastService } from '../services/toast.service';
import { LoaderService } from '../services/loader.service';

@Injectable()
export class HttpUnifiedInterceptor implements HttpInterceptor {
  constructor(
    private tokenService: TokenService,
    private alert: ToastService,
    private loader: LoaderService,
    private router: Router
  ) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const jwt = this.tokenService.get();
    const cloned = jwt
      ? req.clone({ setHeaders: { Authorization: `Bearer ${jwt}` } })
      : req;

    this.loader.show();

    return next.handle(cloned).pipe(
      tap((event) => {
        if (event instanceof HttpResponse) {
          const status = event.status;
          const body = event.body;
          console.log('✅ HTTP Response:', req.url, '→', status);

          if (
            status === 204 ||
            (status === 200 &&
              (body == null ||
                (Array.isArray(body) && body.length === 0)))
          ) {
            this.alert.warning('No data found');
            return;
          }

          if (status === 200 && Array.isArray(body) && body[0]?.AlertMessage) {
            const msg = body[0].AlertMessage;
            const success = body[0].status === true;
            this.alert.show(msg, success ? 'success' : 'error');
          }
        }
      }),

      catchError((err: HttpErrorResponse) => {
        console.error('❌ HTTP Error:', req.url, err.status, err.message);

        if (err.status === 401) {
          this.alert.error('Session expired. Please log in again.');
          this.tokenService.clear();
          localStorage.clear();
          setTimeout(() => this.router.navigate(['/auth/login']), 500);
        } else if (err.status === 409) {
          const msg =
            Array.isArray(err.error) && err.error[0]?.AlertMessage
              ? err.error[0].AlertMessage
              : 'Validation error';
          this.alert.warning(msg);
        } else if (err.status === 0) {
          this.alert.error('Network connection error');
        } else {
          this.alert.error('Server error occurred');
        }

        // Always rethrow so finalize triggers
        return throwError(() => err);
      }),

      // 🧩 GUARANTEED to run no matter what
      finalize(() => {
        this.loader.hide();
        console.log('🧹 Loader hidden for:', req.url);
      })
    );
  }
}
