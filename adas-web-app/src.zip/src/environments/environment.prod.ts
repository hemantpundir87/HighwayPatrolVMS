export const environment = {
  production: true,
  apiBaseUrl: 'https://your-server-domain/api',
  tokenKey: 'adas.jwt'
};
